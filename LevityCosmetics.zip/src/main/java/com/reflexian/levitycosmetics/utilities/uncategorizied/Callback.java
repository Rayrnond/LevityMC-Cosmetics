package com.reflexian.levitycosmetics.utilities.uncategorizied;

public interface Callback<T>
{
    void execute(T response);
}
